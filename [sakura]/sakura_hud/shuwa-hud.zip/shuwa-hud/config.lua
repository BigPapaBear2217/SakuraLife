Config = {}

Config.Debug = false